"use client";
import React, { useState, useMemo } from 'react';
import { Line, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { TrendingUp, Calendar, User, Calculator, X } from 'lucide-react';
import { createClient } from '@/utils/supabase/client';
import { AssessmentForm } from '@/components/assessment/AssessmentForm';
import { DialogProvider } from '@/contexts/DialogContext';
import GlobalDialog from '@/components/GlobalDialog';
import { useAssessment } from '@/hooks/useAssessment';
import AssessmentPDFGenerator from '@/components/assessment/AssessmentPDFGenerator';
import { generateAssessmentPlanAi } from '@/actions/workout-actions';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const LOOKBACK_DAYS = 28;
const BASE_ACTIVITY_FACTOR = 1.2;
const TEF_FACTOR = 0.1;
const MAX_SESSION_SECONDS = 4 * 60 * 60;

const toPositiveNumberOrNull = (value: any): number | null => {
  const num = typeof value === 'string' ? Number(value.replace(',', '.')) : Number(value);
  return Number.isFinite(num) && num > 0 ? num : null;
};

const getWeightKg = (assessment: any): number | null => {
  return toPositiveNumberOrNull(assessment?.weight);
};

const getBodyFatPercent = (assessment: any): number | null => {
  return toPositiveNumberOrNull(assessment?.body_fat_percentage ?? assessment?.bf);
};

const getFatMassKg = (assessment: any): number | null => {
  const stored = toPositiveNumberOrNull(assessment?.fat_mass);
  if (stored) return stored;
  const weight = getWeightKg(assessment);
  const bf = getBodyFatPercent(assessment);
  if (!weight || !bf) return null;
  const computed = (weight * bf) / 100;
  return Number.isFinite(computed) && computed > 0 ? computed : null;
};

const getLeanMassKg = (assessment: any): number | null => {
  const weight = getWeightKg(assessment);
  const bf = getBodyFatPercent(assessment);
  const fatMass = getFatMassKg(assessment);
  const stored = toPositiveNumberOrNull(assessment?.lean_mass);

  if (stored) {
    if (!weight) return stored;
    const epsilon = 0.05;
    const isEqualToWeight = Math.abs(stored - weight) <= epsilon;
    const hasCompositionInputs = !!bf || !!fatMass;
    if (!isEqualToWeight || hasCompositionInputs) {
      return stored > 0 && stored < weight ? stored : null;
    }
  }

  if (!weight || !bf) return null;
  const computed = weight * (1 - bf / 100);
  return Number.isFinite(computed) && computed > 0 && computed < weight ? computed : null;
};

const getBmrKcal = (assessment: any): number | null => {
  return toPositiveNumberOrNull(assessment?.bmr);
};

const getMeasurementCm = (assessment: any, key: string): number | null => {
  return toPositiveNumberOrNull(assessment?.measurements?.[key]);
};

const getSum7Mm = (assessment: any): number | null => {
  return toPositiveNumberOrNull(assessment?.sum7 ?? assessment?.measurements?.sum7);
};

const safeJsonParse = (raw: any): any | null => {
  try {
    if (!raw) return null;
    if (typeof raw === 'object') return raw;
    if (typeof raw !== 'string') return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
};

const safeDateMs = (raw: any): number | null => {
  if (!raw) return null;
  const d = new Date(raw);
  const t = d.getTime();
  return Number.isFinite(t) ? t : null;
};

const safeDateMsStartOfDay = (raw: any): number | null => {
  if (!raw) return null;
  if (typeof raw === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(raw.trim())) {
    const d = new Date(`${raw.trim()}T00:00:00.000`);
    const t = d.getTime();
    return Number.isFinite(t) ? t : null;
  }
  return safeDateMs(raw);
};

const safeDateMsEndOfDay = (raw: any): number | null => {
  if (!raw) return null;
  if (typeof raw === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(raw.trim())) {
    const d = new Date(`${raw.trim()}T23:59:59.999`);
    const t = d.getTime();
    return Number.isFinite(t) ? t : null;
  }
  return safeDateMs(raw);
};

const countSessionSets = (session: any): number => {
  const logs = session?.logs;
  if (logs && typeof logs === 'object') {
    try {
      const values = Object.values(logs);
      if (Array.isArray(values)) {
        const doneCount = values.reduce((acc: number, v: any) => {
          if (v && typeof v === 'object' && v.done === true) return acc + 1;
          return acc;
        }, 0);
        if (doneCount > 0) return doneCount;
        return values.length;
      }
    } catch {
      return 0;
    }
  }

  const exercises = Array.isArray(session?.exercises) ? session.exercises : [];
  let total = 0;
  for (const ex of exercises) {
    const setsArr = Array.isArray(ex?.sets) ? ex.sets : null;
    if (setsArr) {
      total += setsArr.length;
      continue;
    }
    const count = typeof ex?.sets === 'number' ? ex.sets : Number(ex?.sets);
    if (Number.isFinite(count) && count > 0) total += Math.floor(count);
  }
  return total;
};

const estimateStrengthTrainingMet = (seconds: number, setsCount: number): number => {
  const minutes = seconds > 0 ? seconds / 60 : 0;
  if (!Number.isFinite(minutes) || minutes <= 0) return 4.8;
  const setsPerMin = setsCount > 0 ? setsCount / minutes : 0;
  if (!Number.isFinite(setsPerMin) || setsPerMin <= 0) return 4.8;

  if (setsPerMin < 0.25) return 3.8;
  if (setsPerMin < 0.35) return 4.6;
  if (setsPerMin < 0.5) return 5.3;
  return 5.9;
};

const uniqueStrings = (values: any[]): string[] => {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const v of values) {
    if (typeof v !== 'string') continue;
    const s = v.trim();
    if (!s || seen.has(s)) continue;
    seen.add(s);
    out.push(s);
  }
  return out;
};

interface AssessmentHistoryProps {
  studentId?: string;
}

export default function AssessmentHistory({ studentId: propStudentId }: AssessmentHistoryProps) {
  const studentId = propStudentId;
  const supabase = useMemo(() => createClient(), []);
  const { getStudentAssessments } = useAssessment();
  const [assessments, setAssessments] = useState<any[]>([]);
  const [loading, setLoading] = useState(!!studentId);
  const [error, setError] = useState<string | null>(null);
  const [workoutSessions, setWorkoutSessions] = useState<{ dateMs: number; metHours: number }[]>([]);
  const [workoutSessionsLoading, setWorkoutSessionsLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [studentName, setStudentName] = useState<string>('Aluno');
  const [selectedAssessment, setSelectedAssessment] = useState<string | null>(null);
  const [aiPlanByAssessmentId, setAiPlanByAssessmentId] = useState<Record<string, { loading: boolean; error: string | null; plan: any | null; usedAi: boolean }>>({});

  const measurementFields = [
    { key: 'arm', label: 'Braço' },
    { key: 'chest', label: 'Peito' },
    { key: 'waist', label: 'Cintura' },
    { key: 'hip', label: 'Quadril' },
    { key: 'thigh', label: 'Coxa' },
    { key: 'calf', label: 'Panturrilha' }
  ] as const;

  const skinfoldFields = [
    { key: 'triceps', label: 'Tríceps' },
    { key: 'biceps', label: 'Bíceps' },
    { key: 'subscapular', label: 'Subescapular' },
    { key: 'suprailiac', label: 'Suprailíaca' },
    { key: 'abdominal', label: 'Abdominal' },
    { key: 'thigh', label: 'Coxa' },
    { key: 'calf', label: 'Panturrilha' }
  ] as const;

  React.useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        if (!studentId) {
          if (mounted) setError('ID do aluno não fornecido.');
          return;
        }
        if (mounted) {
          setError(null);
          setLoading(true);
        }
        const list = await getStudentAssessments(studentId!);
        if (mounted) setAssessments(list);
        if (mounted) {
          setError(null);
          const latest = list?.[0];
          if (latest?.student_name) {
            setStudentName(latest.student_name);
          } else {
            let resolvedName = 'Aluno';
            try {
              const { data: studentRow } = await supabase
                .from('students')
                .select('name, email, user_id')
                .eq('id', studentId!)
                .maybeSingle();

              if (studentRow) {
                resolvedName = studentRow.name || studentRow.email || resolvedName;
              } else {
                const { data: profile } = await supabase
                  .from('profiles')
                  .select('display_name, email')
                  .eq('id', studentId!)
                  .maybeSingle();
                if (profile) {
                  resolvedName = profile.display_name || profile.email || resolvedName;
                }
              }
            } catch (e) {
              console.error('Erro ao resolver nome do aluno para histórico de avaliações', e);
            }

            setStudentName(resolvedName);
          }
        }
      } catch (e: any) {
        if (mounted) setError(e?.message || 'Erro ao carregar avaliações');
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [studentId, getStudentAssessments, supabase]);

  const handleGenerateAssessmentPlan = async (assessment: any) => {
    try {
      const id = String(assessment?.id || '');
      if (!id) return;

      setAiPlanByAssessmentId((prev) => ({
        ...prev,
        [id]: {
          loading: true,
          error: null,
          plan: prev[id]?.plan ?? null,
          usedAi: prev[id]?.usedAi ?? false,
        },
      }));

      const res = await generateAssessmentPlanAi({
        assessment,
        studentName,
        trainerName: assessment?.trainer_name || '',
        goal: assessment?.goal || assessment?.observations || '',
      });

      if (!res || !res.ok) {
        setAiPlanByAssessmentId((prev) => ({
          ...prev,
          [id]: {
            loading: false,
            error: res?.error ? String(res.error) : 'Falha ao gerar plano tático',
            plan: prev[id]?.plan ?? null,
            usedAi: false,
          },
        }));
        return;
      }

      setAiPlanByAssessmentId((prev) => ({
        ...prev,
        [id]: {
          loading: false,
          error: null,
          plan: res.plan ?? null,
          usedAi: !!res.usedAi,
        },
      }));
    } catch (e: any) {
      const id = String(assessment?.id || '');
      if (!id) return;
      setAiPlanByAssessmentId((prev) => ({
        ...prev,
        [id]: {
          loading: false,
          error: e?.message ? String(e.message) : 'Erro inesperado ao gerar plano tático',
          plan: prev[id]?.plan ?? null,
          usedAi: false,
        },
      }));
    }
  };

  const sortedAssessments = useMemo(() => {
    const safeTime = (raw: any) => {
      const date = new Date(raw);
      const time = date.getTime();
      return Number.isFinite(time) ? time : 0;
    };

    return [...(assessments || [])].sort((a, b) => {
      const aTime = safeTime(a?.date ?? a?.assessment_date);
      const bTime = safeTime(b?.date ?? b?.assessment_date);
      return aTime - bTime;
    });
  }, [assessments]);

  const workoutWindow = useMemo(() => {
    if (!Array.isArray(sortedAssessments) || sortedAssessments.length === 0) return null;
    const minTimes = sortedAssessments
      .map(a => safeDateMsStartOfDay(a?.date ?? a?.assessment_date))
      .filter((t): t is number => typeof t === 'number' && Number.isFinite(t) && t > 0);
    const maxTimes = sortedAssessments
      .map(a => safeDateMsEndOfDay(a?.date ?? a?.assessment_date))
      .filter((t): t is number => typeof t === 'number' && Number.isFinite(t) && t > 0);
    if (minTimes.length === 0 || maxTimes.length === 0) return null;
    const minTime = Math.min(...minTimes);
    const maxTime = Math.max(...maxTimes);
    const lookbackMs = LOOKBACK_DAYS * 24 * 60 * 60 * 1000;
    return {
      from: new Date(minTime - lookbackMs),
      to: new Date(maxTime)
    };
  }, [sortedAssessments]);

  const workoutWindowFromIso = workoutWindow?.from ? workoutWindow.from.toISOString() : null;
  const workoutWindowToIso = workoutWindow?.to ? workoutWindow.to.toISOString() : null;

  React.useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        if (!studentId || !workoutWindowFromIso || !workoutWindowToIso) {
          if (mounted) setWorkoutSessions([]);
          return;
        }
        if (mounted) setWorkoutSessionsLoading(true);

        const candidateId = String(studentId || '').trim();
        const candidateIds: string[] = [];

        try {
          const { data: directProfile } = await supabase
            .from('profiles')
            .select('id')
            .eq('id', candidateId)
            .maybeSingle();

          if (directProfile?.id) {
            candidateIds.push(directProfile.id as string);
          } else {
            const { data: studentRow } = await supabase
              .from('students')
              .select('id, user_id, email')
              .or(`id.eq.${candidateId},user_id.eq.${candidateId}`)
              .maybeSingle();

            if (studentRow?.user_id) candidateIds.push(studentRow.user_id as string);
            if (!studentRow?.user_id && studentRow?.email) {
              const { data: profileByEmail } = await supabase
                .from('profiles')
                .select('id')
                .ilike('email', studentRow.email)
                .maybeSingle();
              if (profileByEmail?.id) candidateIds.push(profileByEmail.id as string);
            }
          }
        } catch {
          candidateIds.push(candidateId);
        }

        const ids = uniqueStrings([candidateId, ...candidateIds]);
        if (ids.length === 0) {
          if (mounted) setWorkoutSessions([]);
          return;
        }

        const baseSelect = 'id, user_id, student_id, date, created_at, completed_at, is_template, notes';
        const fromIso = workoutWindowFromIso;
        const toIso = workoutWindowToIso;
        const fromDay = typeof fromIso === 'string' ? fromIso.split('T')[0] : null;
        const toDay = typeof toIso === 'string' ? toIso.split('T')[0] : null;

        const rows: any[] = [];
        try {
          const { data, error: wErr } = await supabase
            .from('workouts')
            .select(baseSelect)
            .eq('is_template', false)
            .in('user_id', ids)
            .gte('completed_at', fromIso)
            .lte('completed_at', toIso)
            .order('completed_at', { ascending: true });
          if (!wErr && Array.isArray(data)) rows.push(...data);
        } catch {}

        try {
          const { data, error: wErr } = await supabase
            .from('workouts')
            .select(baseSelect)
            .eq('is_template', false)
            .in('student_id', ids)
            .gte('completed_at', fromIso)
            .lte('completed_at', toIso)
            .order('completed_at', { ascending: true });
          if (!wErr && Array.isArray(data)) rows.push(...data);
        } catch {}

        if (fromDay && toDay) {
          try {
            const { data, error: wErr } = await supabase
              .from('workouts')
              .select(baseSelect)
              .eq('is_template', false)
              .in('user_id', ids)
              .gte('date', fromDay)
              .lte('date', toDay)
              .order('date', { ascending: true });
            if (!wErr && Array.isArray(data)) rows.push(...data);
          } catch {}

          try {
            const { data, error: wErr } = await supabase
              .from('workouts')
              .select(baseSelect)
              .eq('is_template', false)
              .in('student_id', ids)
              .gte('date', fromDay)
              .lte('date', toDay)
              .order('date', { ascending: true });
            if (!wErr && Array.isArray(data)) rows.push(...data);
          } catch {}
        }

        const byId = new Map<string, any>();
        for (const r of rows) {
          if (r?.id) byId.set(String(r.id), r);
        }

        const sessions: { dateMs: number; metHours: number }[] = [];
        byId.forEach((r) => {
          const dateMs = safeDateMs(r?.completed_at ?? r?.date ?? r?.created_at);
          if (!dateMs) return;
          const parsed = safeJsonParse(r?.notes);
          const totalTime = toPositiveNumberOrNull(parsed?.totalTime);
          const realTime = toPositiveNumberOrNull(parsed?.realTotalTime);
          let rawSeconds = totalTime || realTime || null;
          if (!rawSeconds) {
            try {
              const exerciseDurations = Array.isArray(parsed?.exerciseDurations)
                ? parsed.exerciseDurations
                : (Array.isArray(parsed?.exercisesDurations) ? parsed.exercisesDurations : null);
              if (exerciseDurations && exerciseDurations.length > 0) {
                const sum = exerciseDurations.reduce((acc: number, v: any) => acc + (Number(v) || 0), 0);
                if (Number.isFinite(sum) && sum > 0) rawSeconds = sum;
              }
            } catch {}
          }
          if (!rawSeconds) return;
          const seconds = Math.min(rawSeconds, MAX_SESSION_SECONDS);
          if (!Number.isFinite(seconds) || seconds <= 0) return;
          const setsCount = countSessionSets(parsed);
          const met = estimateStrengthTrainingMet(seconds, setsCount);
          const metHours = (met * seconds) / 3600;
          if (!Number.isFinite(metHours) || metHours <= 0) return;
          sessions.push({ dateMs, metHours });
        });

        sessions.sort((a, b) => a.dateMs - b.dateMs);

        if (mounted) setWorkoutSessions(sessions);
      } catch {
        if (mounted) setWorkoutSessions([]);
      } finally {
        if (mounted) setWorkoutSessionsLoading(false);
      }
    })();

    return () => {
      mounted = false;
    };
  }, [studentId, supabase, workoutWindowFromIso, workoutWindowToIso]);

  const tdeeByAssessmentId = useMemo(() => {
    const out = new Map<string, number>();
    if (!Array.isArray(sortedAssessments) || sortedAssessments.length === 0) return out;

    const sessions = Array.isArray(workoutSessions) ? workoutSessions : [];

    const dates = sessions.map(s => s.dateMs);
    const prefix: number[] = new Array(sessions.length + 1);
    prefix[0] = 0;
    for (let i = 0; i < sessions.length; i++) {
      prefix[i + 1] = prefix[i] + (Number(sessions[i]?.metHours) || 0);
    }

    const lowerBound = (arr: number[], x: number): number => {
      let lo = 0;
      let hi = arr.length;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (arr[mid] < x) lo = mid + 1;
        else hi = mid;
      }
      return lo;
    };

    const upperBound = (arr: number[], x: number): number => {
      let lo = 0;
      let hi = arr.length;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (arr[mid] <= x) lo = mid + 1;
        else hi = mid;
      }
      return lo;
    };

    const lookbackMs = LOOKBACK_DAYS * 24 * 60 * 60 * 1000;
    for (const assessment of sortedAssessments) {
      const id = assessment?.id ? String(assessment.id) : '';
      if (!id) continue;
      const dateMs = safeDateMsEndOfDay(assessment?.date ?? assessment?.assessment_date);
      if (!dateMs) continue;

      const bmr = getBmrKcal(assessment);
      const weightKg = getWeightKg(assessment);
      if (!bmr || !weightKg) continue;

      let eatPerDay = 0;
      if (sessions.length > 0) {
        const start = dateMs - lookbackMs;
        const l = lowerBound(dates, start);
        const r = upperBound(dates, dateMs);
        const sumMetHours = prefix[r] - prefix[l];
        const eatTotal = weightKg * sumMetHours;
        eatPerDay = eatTotal / LOOKBACK_DAYS;
        if (!Number.isFinite(eatPerDay) || eatPerDay < 0) eatPerDay = 0;
      }

      const baseline = bmr * BASE_ACTIVITY_FACTOR;
      const totalBeforeTef = baseline + eatPerDay;
      const tdee = totalBeforeTef * (1 + TEF_FACTOR);

      if (Number.isFinite(tdee) && tdee > 0) out.set(id, tdee);
    }

    return out;
  }, [sortedAssessments, workoutSessions]);

  const formatDate = (rawDate: any, options?: Intl.DateTimeFormatOptions) => {
    if (!rawDate) return '-';
    const date = new Date(rawDate);
    if (Number.isNaN(date.getTime())) return '-';
    return date.toLocaleDateString('pt-BR', options);
  };

  const formatDateCompact = (rawDate: any) => {
    return formatDate(rawDate, { day: '2-digit', month: '2-digit', year: 'numeric' });
  };

  const formatWeekdayCompact = (rawDate: any) => {
    return formatDate(rawDate, { weekday: 'long' });
  };

  const safeGender = (raw: any) => {
    return raw === 'F' || raw === 'M' ? raw : 'M';
  };

  const chartData = useMemo(() => {
    const labels = sortedAssessments.map(assessment => {
      const rawDate = assessment?.date ?? assessment?.assessment_date;
      const date = new Date(rawDate);
      return Number.isNaN(date.getTime()) ? '-' : date.toLocaleDateString('pt-BR');
    });

    return {
      bodyComposition: {
        labels,
        datasets: [
          {
            label: '% Gordura',
            data: sortedAssessments.map(getBodyFatPercent),
            borderColor: 'rgb(239, 68, 68)',
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            fill: true,
            tension: 0.4
          },
          {
            label: 'Massa Magra (kg)',
            data: sortedAssessments.map(getLeanMassKg),
            borderColor: 'rgb(34, 197, 94)',
            backgroundColor: 'rgba(34, 197, 94, 0.1)',
            fill: true,
            tension: 0.4
          },
          {
            label: 'Massa Gorda (kg)',
            data: sortedAssessments.map(getFatMassKg),
            borderColor: 'rgb(245, 158, 11)',
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            fill: true,
            tension: 0.4
          }
        ]
      },
      weightProgress: {
        labels,
        datasets: [
          {
            label: 'Peso (kg)',
            data: sortedAssessments.map(getWeightKg),
            borderColor: 'rgb(59, 130, 246)',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            fill: true,
            tension: 0.4
          }
        ]
      },
      measurements: {
        labels,
        datasets: [
          {
            label: 'Braço (cm)',
            data: sortedAssessments.map(a => getMeasurementCm(a, 'arm')),
            backgroundColor: 'rgba(168, 85, 247, 0.8)'
          },
          {
            label: 'Peito (cm)',
            data: sortedAssessments.map(a => getMeasurementCm(a, 'chest')),
            backgroundColor: 'rgba(59, 130, 246, 0.8)'
          },
          {
            label: 'Cintura (cm)',
            data: sortedAssessments.map(a => getMeasurementCm(a, 'waist')),
            backgroundColor: 'rgba(236, 72, 153, 0.8)'
          },
          {
            label: 'Quadril (cm)',
            data: sortedAssessments.map(a => getMeasurementCm(a, 'hip')),
            backgroundColor: 'rgba(14, 165, 233, 0.8)'
          },
          {
            label: 'Coxa (cm)',
            data: sortedAssessments.map(a => getMeasurementCm(a, 'thigh')),
            backgroundColor: 'rgba(34, 197, 94, 0.8)'
          },
          {
            label: 'Panturrilha (cm)',
            data: sortedAssessments.map(a => getMeasurementCm(a, 'calf')),
            backgroundColor: 'rgba(251, 191, 36, 0.8)'
          },
          {
            label: 'Dobras Soma (mm)',
            data: sortedAssessments.map(getSum7Mm),
            backgroundColor: 'rgba(245, 158, 11, 0.8)'
          }
        ]
      }
    };
  }, [sortedAssessments]);

  const chartHasData = useMemo(() => {
    const hasNumber = (data: any): boolean => {
      return Array.isArray(data) && data.some(v => typeof v === 'number' && Number.isFinite(v));
    };

    const hasDatasetNumbers = (datasets: any): boolean => {
      return Array.isArray(datasets) && datasets.some(ds => hasNumber(ds?.data));
    };

    return {
      bodyComposition: hasDatasetNumbers(chartData?.bodyComposition?.datasets),
      weightProgress: hasDatasetNumbers(chartData?.weightProgress?.datasets),
      measurements: hasDatasetNumbers(chartData?.measurements?.datasets)
    };
  }, [chartData]);

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: false,
        text: ''
      }
    },
    scales: {
      y: {
        beginAtZero: true
      }
    }
  };

  const latestAssessment = sortedAssessments[sortedAssessments.length - 1];
  const previousAssessment = sortedAssessments[sortedAssessments.length - 2];

  const getProgress = (currentRaw: any, previousRaw: any) => {
    if (currentRaw === null || currentRaw === undefined) return null;
    if (previousRaw === null || previousRaw === undefined) return null;
    const current = Number(currentRaw);
    const previous = Number(previousRaw);
    if (!Number.isFinite(current) || !Number.isFinite(previous) || previous === 0) return null;
    const change = current - previous;
    const percentage = (change / previous) * 100;
    if (!Number.isFinite(percentage)) return null;
    return { change, percentage };
  };

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center bg-neutral-900 text-white">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500 mx-auto mb-4"></div>
          <p className="text-neutral-400">Carregando histórico de avaliações...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 bg-neutral-900">
        <div className="bg-red-900/20 border border-red-500/40 rounded-xl p-4 text-red-400">
          Erro ao carregar histórico: {error}
        </div>
      </div>
    );
  }

  if (assessments.length === 0) {
    return (
      <div className="p-6 bg-neutral-900">
        <div className="bg-neutral-800 rounded-xl border border-neutral-700 p-8 text-center">
          <TrendingUp className="w-16 h-16 text-neutral-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">Nenhuma avaliação encontrada</h2>
          <p className="text-neutral-400">Este aluno ainda não possui avaliações físicas registradas.</p>
        </div>
      </div>
    );
  }

  return (
    <DialogProvider>
    <GlobalDialog />
      <div className="p-4 bg-neutral-900 text-white">
      {/* Cabeçalho escuro com ações */}
      <div className="bg-neutral-800 rounded-xl border border-neutral-700 p-6 mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
          <div className="flex items-center">
            <User className="w-8 h-8 text-yellow-500 mr-3" />
            <div>
              <h1 className="text-xl font-black">Avaliações Físicas</h1>
              <p className="text-neutral-400 text-sm">Gerencie as avaliações e acompanhe a evolução</p>
            </div>
          </div>
          <div className="w-full sm:w-auto flex items-center gap-2">
            <div className="grid grid-cols-2 gap-2 flex-1 sm:flex-none">
              <button
                onClick={() => setShowForm(true)}
                className="w-full min-h-[44px] px-4 py-2 rounded-xl bg-yellow-500 text-black font-black shadow-lg shadow-yellow-500/20 hover:bg-yellow-400 transition-all duration-300 active:scale-95"
              >
                + Nova Avaliação
              </button>
              <button
                onClick={() => setShowHistory(true)}
                className="w-full min-h-[44px] px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-700 text-neutral-200 font-bold hover:bg-neutral-800 transition-all duration-300 active:scale-95"
              >
                Ver Histórico
              </button>
            </div>
            <button
              onClick={() => { if (typeof window !== 'undefined') window.history.back(); }}
              className="shrink-0 w-11 h-11 rounded-xl bg-neutral-900 border border-neutral-700 text-neutral-200 hover:bg-neutral-800 transition-all duration-300 active:scale-95 flex items-center justify-center"
              title="Fechar"
              type="button"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        {latestAssessment && previousAssessment && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="rounded-lg p-4 bg-neutral-900 border border-neutral-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-neutral-400 font-bold uppercase">Peso</span>
                <TrendingUp className="w-4 h-4 text-yellow-500" />
              </div>
              <div className="text-2xl font-bold">{(() => {
                const v = getWeightKg(latestAssessment);
                return v ? `${v.toFixed(1)} kg` : '-';
              })()}</div>
              {(() => {
                const progress = getProgress(getWeightKg(latestAssessment), getWeightKg(previousAssessment));
                return progress && (
                  <div className={`text-sm ${progress.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {progress.change > 0 ? '+' : ''}{progress.change.toFixed(1)} kg ({progress.percentage.toFixed(1)}%)
                  </div>
                );
              })()}
            </div>
            <div className="rounded-lg p-4 bg-neutral-900 border border-neutral-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-neutral-400 font-bold uppercase">% Gordura</span>
                <Calculator className="w-4 h-4 text-yellow-500" />
              </div>
              <div className="text-2xl font-bold">{(() => {
                const bf = getBodyFatPercent(latestAssessment);
                return bf ? `${bf.toFixed(1)}%` : '-';
              })()}</div>
              {(() => {
                const progress = getProgress(
                  getBodyFatPercent(latestAssessment),
                  getBodyFatPercent(previousAssessment)
                );
                return progress && (
                  <div className={`text-sm ${progress.change < 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {progress.change > 0 ? '+' : ''}{progress.change.toFixed(1)}% ({progress.percentage.toFixed(1)}%)
                  </div>
                );
              })()}
            </div>
            <div className="rounded-lg p-4 bg-neutral-900 border border-neutral-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-neutral-400 font-bold uppercase">Massa Magra</span>
                <TrendingUp className="w-4 h-4 text-yellow-500" />
              </div>
              <div className="text-2xl font-bold">{(() => {
                const lm = getLeanMassKg(latestAssessment);
                return lm ? `${lm.toFixed(1)} kg` : '-';
              })()}</div>
              {(() => {
                const currentLm = getLeanMassKg(latestAssessment);
                const previousLm = getLeanMassKg(previousAssessment);
                const progress = getProgress(currentLm, previousLm);
                return progress && (
                  <div className={`text-sm ${progress.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {progress.change > 0 ? '+' : ''}{progress.change.toFixed(1)} kg ({progress.percentage.toFixed(1)}%)
                  </div>
                );
              })()}
            </div>
            <div className="rounded-lg p-4 bg-neutral-900 border border-neutral-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-neutral-400 font-bold uppercase">BMR</span>
                <Calculator className="w-4 h-4 text-yellow-500" />
              </div>
              <div className="text-2xl font-bold">{(() => {
                const v = getBmrKcal(latestAssessment);
                return v ? v.toFixed(0) : '-';
              })()} kcal</div>
              {(() => {
                const progress = getProgress(getBmrKcal(latestAssessment), getBmrKcal(previousAssessment));
                return progress && (
                  <div className={`text-sm ${progress.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {progress.change > 0 ? '+' : ''}{progress.change.toFixed(0)} kcal ({progress.percentage.toFixed(1)}%)
                  </div>
                );
              })()}
            </div>
          </div>
        )}
      </div>

      {/* Gráficos escuros */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-neutral-800 rounded-xl border border-neutral-700 p-6">
          <h3 className="text-lg font-bold text-white mb-4">Evolução da Composição Corporal</h3>
          <div className="h-64">
            {chartHasData.bodyComposition ? (
              <Line data={chartData.bodyComposition} options={chartOptions} />
            ) : (
              <div className="h-full flex items-center justify-center text-neutral-400 text-sm text-center px-6">
                Sem dados de composição corporal suficientes.
              </div>
            )}
          </div>
        </div>
        <div className="bg-neutral-800 rounded-xl border border-neutral-700 p-6">
          <h3 className="text-lg font-bold text-white mb-4">Evolução do Peso</h3>
          <div className="h-64">
            {chartHasData.weightProgress ? (
              <Line data={chartData.weightProgress} options={chartOptions} />
            ) : (
              <div className="h-full flex items-center justify-center text-neutral-400 text-sm text-center px-6">
                Sem dados de peso suficientes.
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-neutral-800 rounded-xl border border-neutral-700 p-6 mb-6">
        <h3 className="text-lg font-bold text-white mb-4">Evolução das Circunferências</h3>
        <div className="h-64">
          {chartHasData.measurements ? (
            <Bar data={chartData.measurements} options={chartOptions} />
          ) : (
            <div className="h-full flex items-center justify-center text-neutral-400 text-sm text-center px-6">
              Sem dados de circunferências suficientes.
            </div>
          )}
        </div>
      </div>

      {/* Lista escura */}
      <div className="bg-neutral-800 rounded-xl border border-neutral-700">
        <div className="p-6 border-b border-neutral-700">
          <h3 className="text-lg font-bold text-white flex items-center">
            <Calendar className="w-5 h-5 mr-2" />
            Histórico Completo
          </h3>
        </div>
        <div id="assessments-history" className="divide-y divide-neutral-700">
          {sortedAssessments.map((assessment) => (
            <div key={assessment.id} className="p-6 hover:bg-neutral-900 transition-colors">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-black text-white text-sm sm:text-base truncate">
                        {formatDateCompact(assessment.date || assessment.assessment_date)}
                      </div>
                      <div className="text-xs text-neutral-500 mt-0.5 truncate">
                        {formatWeekdayCompact(assessment.date || assessment.assessment_date)}
                      </div>
                    </div>
                    <div className="shrink-0 flex items-center gap-2">
                      <span className="px-2.5 py-1 bg-yellow-500/15 text-yellow-400 text-xs rounded-full border border-yellow-500/20 font-bold">
                        {assessment.age ?? '-'} anos
                      </span>
                      {assessment.photos && assessment.photos.length > 0 && (
                        <span className="px-2.5 py-1 bg-green-500/15 text-green-400 text-xs rounded-full border border-green-500/20 font-bold">
                          Com fotos
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4 text-sm">
                    <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-3">
                      <div className="text-[10px] text-neutral-500 font-bold uppercase tracking-wider">Peso</div>
                      <div className="text-white font-black mt-1">{(() => {
                        const w = getWeightKg(assessment);
                        return w ? `${w.toFixed(1)} kg` : '-';
                      })()}</div>
                    </div>
                    <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-3">
                      <div className="text-[10px] text-neutral-500 font-bold uppercase tracking-wider">% Gordura</div>
                      <div className="text-white font-black mt-1">{(() => {
                        const bf = getBodyFatPercent(assessment);
                        return bf ? `${bf.toFixed(1)}%` : '-';
                      })()}</div>
                    </div>
                    <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-3">
                      <div className="text-[10px] text-neutral-500 font-bold uppercase tracking-wider">Massa Magra</div>
                      <div className="text-white font-black mt-1">{(() => {
                        const lm = getLeanMassKg(assessment);
                        return lm ? `${lm.toFixed(1)} kg` : '-';
                      })()}</div>
                    </div>
                    <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-3">
                      <div className="text-[10px] text-neutral-500 font-bold uppercase tracking-wider">BMR</div>
                      <div className="text-white font-black mt-1">{(() => {
                        const v = getBmrKcal(assessment);
                        return v ? `${v.toFixed(0)} kcal` : '-';
                      })()}</div>
                    </div>
                    <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-3">
                      <div className="text-[10px] text-neutral-500 font-bold uppercase tracking-wider">TDEE</div>
                      <div className="text-white font-black mt-1">{(() => {
                        if (workoutSessionsLoading) return '...';
                        const v = tdeeByAssessmentId.get(String(assessment.id));
                        return v ? `${v.toFixed(0)} kcal` : '-';
                      })()}</div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-row flex-wrap items-center gap-2 md:justify-end">
                  <button
                    onClick={() => setSelectedAssessment(selectedAssessment === assessment.id ? null : assessment.id)}
                    className="min-h-[44px] px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-700 text-yellow-500 hover:text-yellow-400 font-black hover:bg-neutral-800 transition-all duration-300 active:scale-95"
                    type="button"
                  >
                    {selectedAssessment === assessment.id ? 'Ocultar' : 'Detalhes'}
                  </button>
                  <AssessmentPDFGenerator
                    formData={{
                      assessment_date: String(assessment.assessment_date || ''),
                      weight: String(assessment.weight || ''),
                      height: String(assessment.height || ''),
                      age: String(assessment.age || ''),
                      gender: safeGender(assessment.gender),
                      arm_circ: String(assessment.measurements?.arm || ''),
                      chest_circ: String(assessment.measurements?.chest || ''),
                      waist_circ: String(assessment.measurements?.waist || ''),
                      hip_circ: String(assessment.measurements?.hip || ''),
                      thigh_circ: String(assessment.measurements?.thigh || ''),
                      calf_circ: String(assessment.measurements?.calf || ''),
                      triceps_skinfold: String(assessment.skinfolds?.triceps || ''),
                      biceps_skinfold: String(assessment.skinfolds?.biceps || ''),
                      subscapular_skinfold: String(assessment.skinfolds?.subscapular || ''),
                      suprailiac_skinfold: String(assessment.skinfolds?.suprailiac || ''),
                      abdominal_skinfold: String(assessment.skinfolds?.abdominal || ''),
                      thigh_skinfold: String(assessment.skinfolds?.thigh || ''),
                      calf_skinfold: String(assessment.skinfolds?.calf || ''),
                      observations: ''
                    }}
                    studentName={assessment.student_name}
                    trainerName={assessment.trainer_name}
                    assessmentDate={new Date(assessment.assessment_date || Date.now())}
                  />
                  <button
                    type="button"
                    onClick={() => handleGenerateAssessmentPlan(assessment)}
                    className="min-h-[44px] px-4 py-2 rounded-xl bg-yellow-500 text-black font-black hover:bg-yellow-400 transition-all duration-300 active:scale-95"
                  >
                    {aiPlanByAssessmentId[String(assessment.id)]?.loading ? 'Gerando plano…' : 'Plano Tático (AI)'}
                  </button>
                </div>
              </div>
              {selectedAssessment === assessment.id && (
                <div className="mt-4 pt-4 border-t border-neutral-700">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-bold text-white mb-2">Dobras Cutâneas (mm)</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        {skinfoldFields.map(({ key, label }) => {
                          const value = (assessment.skinfolds || {})[key];
                          return (
                            <div key={key} className="flex justify-between">
                              <span className="text-neutral-400">{label}:</span>
                              <span className="font-medium text-white">{value === null || value === undefined || value === '' ? '-' : String(value)}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-bold text-white mb-2">Circunferências (cm)</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        {measurementFields.map(({ key, label }) => {
                          const value = (assessment.measurements || {})[key];
                          return (
                            <div key={key} className="flex justify-between">
                              <span className="text-neutral-400">{label}:</span>
                              <span className="font-medium text-white">{value === null || value === undefined || value === '' ? '-' : String(value)}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                  {(() => {
                    const s = aiPlanByAssessmentId[String(assessment.id)];
                    if (!s) return null;
                    const plan = s.plan && typeof s.plan === 'object' ? s.plan : null;
                    if (!plan && !s.loading && !s.error) return null;
                    return (
                      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-neutral-900/70 border border-neutral-700 rounded-xl p-4">
                          <div className="text-xs font-black uppercase tracking-widest text-yellow-500 mb-2">Resumo Tático</div>
                          {s.loading ? (
                            <div className="text-sm text-neutral-300">Gerando plano tático personalizado…</div>
                          ) : s.error ? (
                            <div className="text-sm text-red-400">{s.error}</div>
                          ) : plan ? (
                            <ul className="text-sm text-neutral-200 space-y-1 list-disc list-inside">
                              {Array.isArray(plan.summary) && plan.summary.length > 0
                                ? plan.summary.map((item: any, idx: number) => (
                                    <li key={idx}>{String(item || '')}</li>
                                  ))
                                : null}
                            </ul>
                          ) : null}
                        </div>
                        {plan ? (
                          <div className="bg-neutral-900/70 border border-neutral-700 rounded-xl p-4 space-y-3">
                            {Array.isArray(plan.training) && plan.training.length > 0 && (
                              <div>
                                <div className="text-xs font-black uppercase tracking-widest text-yellow-500 mb-1">Treino</div>
                                <ul className="text-sm text-neutral-200 space-y-1 list-disc list-inside">
                                  {plan.training.map((item: any, idx: number) => (
                                    <li key={idx}>{String(item || '')}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                            {Array.isArray(plan.nutrition) && plan.nutrition.length > 0 && (
                              <div>
                                <div className="text-xs font-black uppercase tracking-widest text-yellow-500 mb-1">Nutrição</div>
                                <ul className="text-sm text-neutral-200 space-y-1 list-disc list-inside">
                                  {plan.nutrition.map((item: any, idx: number) => (
                                    <li key={idx}>{String(item || '')}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                            {Array.isArray(plan.habits) && plan.habits.length > 0 && (
                              <div>
                                <div className="text-xs font-black uppercase tracking-widest text-yellow-500 mb-1">Hábitos</div>
                                <ul className="text-sm text-neutral-200 space-y-1 list-disc list-inside">
                                  {plan.habits.map((item: any, idx: number) => (
                                    <li key={idx}>{String(item || '')}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                            {Array.isArray(plan.warnings) && plan.warnings.length > 0 && (
                              <div>
                                <div className="text-xs font-black uppercase tracking-widest text-yellow-500 mb-1">Alertas</div>
                                <ul className="text-sm text-neutral-300 space-y-1 list-disc list-inside">
                                  {plan.warnings.map((item: any, idx: number) => (
                                    <li key={idx}>{String(item || '')}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        ) : null}
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Modal do Formulário */}
      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
          <div className="bg-neutral-900 w-full max-w-3xl rounded-2xl border border-neutral-800 shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="p-4 border-b border-neutral-800 flex justify-between items-center">
              <h3 className="font-bold text-white">Nova Avaliação</h3>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-neutral-800 rounded-full"><X className="w-5 h-5 text-neutral-400"/></button>
            </div>
            <div className="p-4 max-h-[80vh] overflow-y-auto bg-neutral-900">
              <AssessmentForm
                studentId={studentId!}
                studentName={studentName}
                onSuccess={() => { setShowForm(false); location.reload(); }}
                onCancel={() => setShowForm(false)}
              />
            </div>
          </div>
        </div>
      )}

      {/* Modal de Histórico */}
      {showHistory && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowHistory(false)}>
          <div className="bg-neutral-900 w-full max-w-3xl rounded-2xl border border-neutral-800 shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="p-4 border-b border-neutral-800 flex justify-between items-center">
              <h3 className="font-bold text-white">Histórico de Avaliações</h3>
              <button onClick={() => setShowHistory(false)} className="p-2 hover:bg-neutral-800 rounded-full"><X className="w-5 h-5 text-neutral-400"/></button>
            </div>
            <div className="p-4 max-h-[80vh] overflow-y-auto space-y-3">
              {sortedAssessments.map(a => (
                <div key={a.id} className="bg-neutral-800 p-3 rounded-xl border border-neutral-700">
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3">
                    <div>
                      <div className="font-black text-white">{formatDateCompact(a.date || a.assessment_date)}</div>
                      <div className="text-xs text-neutral-500">{(() => {
                        const w = getWeightKg(a);
                        const bf = getBodyFatPercent(a);
                        const weightLabel = w ? `${w.toFixed(1)} kg` : '-';
                        const bfLabel = bf ? `${bf.toFixed(1)}%` : '-';
                        return `Peso ${weightLabel} • % Gordura ${bfLabel}`;
                      })()}</div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        onClick={() => setSelectedAssessment(selectedAssessment === a.id ? null : a.id)}
                        className="min-h-[44px] px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-700 text-yellow-500 hover:text-yellow-400 font-black hover:bg-neutral-800 transition-all duration-300 active:scale-95"
                        type="button"
                      >
                        Detalhes
                      </button>
                      <AssessmentPDFGenerator
                        formData={{
                          assessment_date: String(a.assessment_date || ''),
                          weight: String(a.weight || ''),
                          height: String(a.height || ''),
                          age: String(a.age || ''),
                          gender: safeGender(a.gender),
                          arm_circ: String(a.measurements?.arm || ''),
                          chest_circ: String(a.measurements?.chest || ''),
                          waist_circ: String(a.measurements?.waist || ''),
                          hip_circ: String(a.measurements?.hip || ''),
                          thigh_circ: String(a.measurements?.thigh || ''),
                          calf_circ: String(a.measurements?.calf || ''),
                          triceps_skinfold: String(a.skinfolds?.triceps || ''),
                          biceps_skinfold: String(a.skinfolds?.biceps || ''),
                          subscapular_skinfold: String(a.skinfolds?.subscapular || ''),
                          suprailiac_skinfold: String(a.skinfolds?.suprailiac || ''),
                          abdominal_skinfold: String(a.skinfolds?.abdominal || ''),
                          thigh_skinfold: String(a.skinfolds?.thigh || ''),
                          calf_skinfold: String(a.skinfolds?.calf || ''),
                          observations: ''
                        }}
                        studentName={studentName}
                        trainerName={a.trainer_name}
                        assessmentDate={new Date(a.assessment_date || Date.now())}
                      />
                    </div>
                  </div>
                  {selectedAssessment === a.id && (
                    <div className="mt-3 pt-3 border-t border-neutral-700">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <h4 className="font-bold text-white mb-2">Dobras Cutâneas (mm)</h4>
                          <div className="grid grid-cols-2 gap-2">
                          {skinfoldFields.map(({ key, label }) => {
                            const value = (a.skinfolds || {})[key];
                            return (
                              <div key={key} className="flex justify-between">
                                <span className="text-neutral-400">{label}:</span>
                                <span className="font-medium text-white">{value === null || value === undefined || value === '' ? '-' : String(value)}</span>
                              </div>
                            );
                          })}
                          </div>
                        </div>
                        <div>
                          <h4 className="font-bold text-white mb-2">Circunferências (cm)</h4>
                          <div className="grid grid-cols-2 gap-2">
                          {measurementFields.map(({ key, label }) => {
                            const value = (a.measurements || {})[key];
                            return (
                              <div key={key} className="flex justify-between">
                                <span className="text-neutral-400">{label}:</span>
                                <span className="font-medium text-white">{value === null || value === undefined || value === '' ? '-' : String(value)}</span>
                              </div>
                            );
                          })}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
    </DialogProvider>
  );
}

