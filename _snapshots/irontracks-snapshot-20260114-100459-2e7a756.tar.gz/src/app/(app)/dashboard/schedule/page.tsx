import ScheduleClient from './ScheduleClient'

export const dynamic = 'force-dynamic'

export default function SchedulePage() {
  return <ScheduleClient />
}

