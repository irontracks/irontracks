'use client';

export { default } from '@/app/page';
