import MarketplaceClient from './MarketplaceClient'

export const dynamic = 'force-dynamic'

export default function MarketplacePage() {
  return <MarketplaceClient />
}

