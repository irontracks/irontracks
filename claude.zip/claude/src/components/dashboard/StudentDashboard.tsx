export { default } from './StudentDashboard3'
export * from './StudentDashboard3'
